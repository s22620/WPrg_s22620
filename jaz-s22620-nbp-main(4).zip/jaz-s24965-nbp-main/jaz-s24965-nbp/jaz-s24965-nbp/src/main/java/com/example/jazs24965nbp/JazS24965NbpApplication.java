package com.example.jazs24965nbp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JazS24965NbpApplication {

    public static void main(String[] args) {
        SpringApplication.run(JazS24965NbpApplication.class, args);
    }

}
